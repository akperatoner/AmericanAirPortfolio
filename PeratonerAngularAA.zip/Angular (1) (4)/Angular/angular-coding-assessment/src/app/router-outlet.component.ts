import { Component } from '@angular/core';
import { EmailValidator } from '@angular/forms';
import { Validators } from '@angular/forms'
import { Router } from '@angular/router';

import { RouterOutlet } from './router-outlet';

@Component({
  selector: 'router-outlet',
  templateUrl: './router-outlet.component.html',
  styleUrls: ['./router-outlet.component.css']
})
export class RouterOutletComponent {

  //dropdown options
  memberships = ['Executive Platinum', 'Platinum Pro',
    'Platinum'];

  //initial data in text fields on page load
  model = new RouterOutlet('Email@Email.com', 'password', this.memberships[1]);

  //form is not submitted initially
  submitted = false;

  /****************************
   * onSubmit() has no return as it is a void function that only does
   * simple computations and is more of an event changer. It checks
   * the current information in the form and checks if the data is
   * valid to be submitted. It prompts a user with a confirm message
   * and then handles events accordingly.
   *
   * params: none
   * return: void
   * ****************************/
  onSubmit() {

    if (this.model.email == "" || this.model.password == "" || this.model.membership == null) {
      //ask user if they wish to submit anyways
      let bar = confirm("One or more fields may be empty, proceed?");
      console.log(bar);
      if (bar.valueOf() == false) {
        this.submitted = false;
      }
      else {
        this.submitted = true;
      }
    }
    else {
      this.submitted = true;
    }


  }

  /****************************
   * checkSpecialCharacter(string) grabs the current string in the
   * password field and checks if it contains a special character.
   * String is tested against list of special characters to see if
   * it is present, otherwise, it returns false.
   *
   * params: tempString of type string
   * return: boolean
   * ****************************/
  checkSpecialCharacter(tempString: string) {
    var format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;

    if (format.test(tempString)) {
      return true;
    }
    else {
      return false;
    }
  }

  /****************************
  * newMember() clears the field of the form and replaces it
  * with empty fields to enter a new member. If any of the fields
  * are currently filled, the program prompts the user to see if
  * they wish to delete currently existing data.
  *
  * params: none
  * return: void
  * ****************************/
  newMember() {


    if (this.model.email.length > 0) {
      //ask user if they wish to clear the fields 
      let bar = confirm("One or more fields may be filled, proceed?");
      console.log(bar);
      if (bar.valueOf() == true) {
        this.model = new RouterOutlet('', '', '');
      }
    }
    else if (this.model.password.length > 0) {
      let bar = confirm("One or more fields may be filled, proceed?");
      console.log(bar);
      if (bar.valueOf() == true) {
        this.model = new RouterOutlet('', '', '');
      }
    }
    else if (this.model.membership.length > 0) {
      let bar = confirm("One or more fields may be filled, proceed?");
      console.log(bar);
      if (bar.valueOf() == true) {
        this.model = new RouterOutlet('', '', '');
      }
    }
  }

}
