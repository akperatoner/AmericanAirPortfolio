export class RouterOutlet {

  constructor(
    
    public email: string,
    public password: string,
    public membership: string
  ) {  }

}
