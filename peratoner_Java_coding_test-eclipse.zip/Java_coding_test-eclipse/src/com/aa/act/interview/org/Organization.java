package com.aa.act.interview.org;

import java.util.Optional;

public abstract class Organization {

	private Position root;
	private int numberOfEmployees;
	
	public Organization() {
		root = createOrganization();
		numberOfEmployees = 0;
	}
	
	protected abstract Position createOrganization();
	
	/**
	 * hire the given person as an employee in the position that has that title
	 * 
	 * @param person
	 * @param title
	 * @return the newly filled position or empty if no position has that title
	 */
	public Optional<Position> hire(Name person, String title) { 
	//your code here
		//call recursive search for position
		Optional<Position> tempPosition = ifPositionExists(root, title);
		
		//check is position was found
		if(!tempPosition.isEmpty()) {
			Position pos = tempPosition.get();
			
			//since position found, check if it is filled
			if(pos.isFilled()) {
				System.out.println(pos.getTitle() + " position isn't open, sorry "+ person.getFirst() + " " + person.getLast() + ".");
			} 
			else{
				//create employee and fill position
				numberOfEmployees = numberOfEmployees+1;
				Employee tempEmployee = new Employee(numberOfEmployees, person);
				tempPosition.get().setEmployee(Optional.of(tempEmployee));			
			}
		}
		else{
			//position doesn't exist
			System.out.println("Position doesn't exist");
		}
 
		return tempPosition;
	}
	
	/*
	 * Note: I attempted to use Position only at first since I thought
	 * it would be easier since there were already functions defined
	 * in the class that I could use and have little experience with Optional,
	 * but I changed it to Optional<Position> so it matched the hire function.
	 * I got my idea from the printOrganization function that used just Position 
	 * and Strings but it didn't carry over to optional but the logic was
	 * similar.
	 */
	public Optional<Position> ifPositionExists(Position pos, String title) {
		
		//turn Position into Optional object
		Optional<Position> tempPosition = Optional.of(pos);
			  
		//if the title matches return the position title
		if(tempPosition.get().getTitle().equals(title)) {
			return tempPosition;
		} 
		else{
			//iterate through sub-positions in HashSet and recursively call 
			//isPostionExists to check if the function exists
			for(Position p: pos.getDirectReports()) {
				tempPosition = ifPositionExists(p, title);
			    	
				//if there is no subset of positions, return
				if(!tempPosition.isEmpty()) {
					return tempPosition;
				}
			}
		}
			  
		return Optional.empty();

	}
	
	

	@Override
	public String toString() {
		return printOrganization(root, "");
	}
	
	private String printOrganization(Position pos, String prefix) {
		StringBuffer sb = new StringBuffer(prefix + "+-" + pos.toString() + "\n");
		for(Position p : pos.getDirectReports()) {
			sb.append(printOrganization(p, prefix + "\t"));
		}
		return sb.toString();
	}
}
